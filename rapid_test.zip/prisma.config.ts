import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

export default {
  schema: './prisma/schema.prisma',
  migrations: {
    path: './prisma/migrations',
  },
  datasource: {
    url: process.env.DATABASE_URL!,
  },
};